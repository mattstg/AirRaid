﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PrefabFileDir
{
    public static readonly string PLAYER_RESOURCE_PATH = "Prefabs/Player";
    public static readonly string UI_ABILITY_RESOURCE_PATH = "Prefabs/UI/UIAbility";
}
