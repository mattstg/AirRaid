﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPreviousLocations
{
    public static ArrayList playerPositionsQueue = new ArrayList();
    public static ArrayList playerRotationsQueue = new ArrayList();
}
